﻿using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public class MemoryBookRepository : IBookRepository
    {
        private static List<Book> books = new List<Book>
        {
            new Book { BookId = 1, Title = "The Magic Tree", Author = "John Smith", Price = 200 },
            new Book { BookId = 2, Title = "The Lost Island", Author = "Emily Brown", Price = 250 },
            new Book { BookId = 3, Title = "The Secret Garden", Author = "Sarah Wilson", Price = 300 }
        };

        public IEnumerable<Book> GetAllBooks()
        {
            return books;
        }

        public Book GetBookById(int id)
        {
            return books.FirstOrDefault(b => b.BookId == id);
        }

        public void AddBook(Book book)
        {
            book.BookId = books.Max(b => b.BookId) + 1;
            books.Add(book);
        }

        public void DeleteBook(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book != null)
            {
                books.Remove(book);
            }
        }
    }
}